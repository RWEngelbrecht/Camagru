<?php
function create_db($db_name) {
	$db_host = "localhost";
	$db_user = "root";
	$db_passwd = "qwerqwer";
	// $db_name = "db_camagru";
	$dsn = "mysql:host=".$db_host;
	try {
		$dbh = new PDO($dsn, $db_user, $db_passwd);
		$dbh->setAttribute(PDO::ERRMODE_EXCEPTION);
		$dbh->query("CREATE DATABASE IF NOT EXISTS $db_name");
		$dbh->query("use $db_name");
	}
	catch(PDOException $e) {
		echo "ERROR: ".$e->getMessage();
	}
}
// if ($dbh)
// 	echo "success!\n";
?>
