<?php
include ("database.php");
create_db("db_camagru");
// global $dsn;
?>
